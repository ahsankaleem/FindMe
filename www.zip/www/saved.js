   
  // web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyAwNO_dwyUdk4yroDhemEc62UQjqFqCLi8",
    authDomain: "phonegapfinal-16c18.firebaseapp.com",
    databaseURL: "https://phonegapfinal-16c18.firebaseio.com",
    projectId: "phonegapfinal-16c18",
    storageBucket: "phonegapfinal-16c18.appspot.com",
    messagingSenderId: "1067509049031",
    appId: "1:1067509049031:web:fef5cf11274f580ca300e2"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

var database = firebase.database();
var ref = database.ref('score');

var data = {
    
    name= "Ahsan",
    Score = 45
    
}
    
ref.push(data);