/* 
This code's author is Ahsan Kaleem with student id:2019391, it is for CCT college mobile application project.
*/ 

// App variable default by Phonegap 
var app = 
{
    // Application Constructor
    initialize: function() 
    {
        this.bindEvents();
        var currencyCode;
        if (cordova.platformId == 'android') 
        {
    StatusBar.backgroundColorByHexString("#C4E909");
        }
    },
    
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() 
    {
        document.addEventListener('deviceready', this.onDeviceReady, false);
        
    },
    
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() 
    {
       // app.receivedEvent('deviceready');
       navigator.geolocation.getCurrentPosition(app.onSuccess, app.onError);
        
    },
    
// onSunces funtion to gather latitude and longitude and feeding the google map.
    onSuccess: function(position)
    {
        var longitude = position.coords.longitude;
        var latitude = position.coords.latitude;
        var times = position.timestamp;
        var latLong = new google.maps.LatLng(latitude, longitude);
         
        var mapOptions = 
            {
            center: latLong,
            zoom: 13,
            mapTypeId: google.maps.MapTypeId.ROADMAP
            };

        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
	
        var marker = new google.maps.Marker(
            {
              position: latLong,
              map: map,
              title: 'my location'
            });
        
    },
    
//onError function with alert to show the error.    
  onError: function(error)
    {
        alert("the code is " + error.code + ". \n" + "message: " + error.message);
    },     

};


//Global Variables
    var country;
    var state;
    var cityName;
    var County; 
    var postcode;
    var roadName;
    var currencyName; 
    var formatted;
    var currencyCode;
    var currencyName;



// Weather update Function
    function getLocationInfo() 
{

    navigator.geolocation.getCurrentPosition
    (onLocationSuccess, onLocationError, { enableHighAccuracy: true });
}



// Success callback for get geo coordinates
    var onLocationSuccess = function (position) 
{

//Assigning variables with coords values
    Latitude = position.coords.latitude;
    Longitude = position.coords.longitude;

// Calling function with arguments receievd in the function.
    getLocation(Latitude, Longitude);
    getWeather(Latitude, Longitude);
}


// Get weather by using coordinates
    function getLocation(latitude, longitude) 
{

// Requesting for api information 
    var http = new XMLHttpRequest();
    var LocationAppKey = "01ddd6cd5fb64aef91cdcf051478fc88";

    const queryString = 
          'https://api.opencagedata.com/geocode/v1/json?q='
      + latitude + '+' + longitude + '&key=' + LocationAppKey;
 
    http.open('GET', queryString);
    http.send();
    http.onreadystatechange = (e) => 
    {
    var response = http.responseText;
    var responseJSON = JSON.parse(response);
    
    
// Assigning Values to the Variables 
     this.cityName = responseJSON.results[0].components.city;
     this.postcode = responseJSON.results[0].components.postcode;
     this.state = responseJSON.results[0].components.state;
     this.country = responseJSON.results[0].components.country;
     this.formatted = responseJSON.results[0].formatted;
     this.roadName = responseJSON.results[0].components.road;
     this.County = responseJSON.results[0].components.county;
     this.currencyName = responseJSON.results[0].annotations.currency.name;
     this.currencyCode = responseJSON.results[0].annotations.currency.iso_code;
    
// Feeding Values to the Html 
   document.getElementById("Country").innerHTML = country;   
   document.getElementById("State").innerHTML = state;
   document.getElementById("City").innerHTML = cityName;
   document.getElementById("County").innerHTML = County;
   document.getElementById("Post").innerHTML = postcode;
   document.getElementById("Road").innerHTML = roadName;
   document.getElementById("Currency").innerHTML = currencyName; 
   document.getElementById("Address").innerHTML = formatted;

    
//Welcome Message
    alert("Welcome to Find me App" + " You are in: " + cityName);
    
}

}

// Function to get weather updates through API Request
function getWeather(latitude, longitude) 
{
    var http = new XMLHttpRequest();
    var OpenWeatherAppKey = "e3a7f062ee37e183cd9b87eddc6eebc1";

    const queryString =
      'http://api.openweathermap.org/data/2.5/weather?lat='
      + latitude + '&lon=' + longitude + '&appid=' + OpenWeatherAppKey + '&units=imperial';
    
    http.open('GET', queryString);
    http.send();
    http.onreadystatechange = (e) => 
    {
        
//Retrieving information using the JSON Object calls and storing in the variables
    var response = http.responseText;
    var responseJSON = JSON.parse(response);
    var city =  responseJSON.name;
    var temp =  responseJSON.main.temp +' °F';
    var humidity = responseJSON.main.humidity +'%';
    var wind =  responseJSON.wind.speed + ' m/s' ;
    var sunr =  responseJSON.sys.sunrise ;
    var clouds =  responseJSON.clouds.all +' %';
    var des = ' There is ' +responseJSON.weather[0].description +' in '+ responseJSON.name +'.';
    
    
// Converst Unix timestamp to local-time
    var seconds = sunr;
    var date = new Date(seconds * 1000);
    var strTime = date.toLocaleTimeString();
            
//Assigning HTML with the variable values
    document.getElementById("Temp").innerHTML = temp;
    document.getElementById("Humidity").innerHTML = humidity;
    document.getElementById("Wind").innerHTML = wind;
    document.getElementById("Cloud").innerHTML = clouds;
    document.getElementById("des").innerHTML = des;
    document.getElementById("sunr").innerHTML = strTime;
    document.getElementById("City").innerHTML = city;

}
}


// Error callback function

    function onLocationError(error) 
{
    console.log('code: ' + error.code + '\n' +
        'message: ' + error.message + '\n');
}




//Mobile Menu function
    function myFunction() 
{
    var x = document.getElementById("myLinks");
    if (x.style.display === "block") 
    {
    x.style.display = "none";
    } else 
    {
    x.style.display = "block";
    }
}

 
// Variable for firebase config to connect with firebase database
    var config = 
{
         
//Assigned personal firebase account information included API key 
    apiKey: "AIzaSyAwNO_dwyUdk4yroDhemEc62UQjqFqCLi8",
    authDomain: "phonegapfinal-16c18.firebaseapp.com",
    databaseURL: "https://phonegapfinal-16c18.firebaseio.com",
    projectId: "phonegapfinal-16c18",
    storageBucket: "phonegapfinal-16c18.appspot.com",
    messagingSenderId: "1067509049031",
    appId: "1:1067509049031:web:fef5cf11274f580ca300e2"
};

// Initialize Firebase app
    firebase.initializeApp(config);

// Reference to your entire Firebase database
    var myFirebase = firebase.database().ref();

        var SavedVisit = myFirebase.child("SavedVisit");
        var currentdate = new Date();
        var datentime= currentdate.getDate() + "/"
                + (currentdate.getMonth()+1)  + "/" 
                + currentdate.getFullYear() + " @ "  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds(); 

       var pushData = function(){screen
                    
//Sending (Pushing) the data to firebase 
       SavedVisit.push(
    {
        "Country":this.country,
        "State":this.state,
        "City" : cityName,
        "County" : County,
        "Post" : postcode,
        "Road" : roadName,
        "Date" : datentime, 
        "Address" : formatted
    });
        alert('Information has been Saved');                                 
}
   

//CurrencyExchange Function using API Request and Json object calls
    function currencyConverter() 
{
    var amount = document.getElementById("amount").value;
    
    var http = new XMLHttpRequest();
    const url = 'http://apilayer.net/api/live?access_key=520f8452a29405a2ec63ca2037a9ce5e'
    http.open('GET', url);
    http.send();
    http.onreadystatechange = (e) => {
    var response = http.responseText;
    var responseJSON = JSON.parse(response);
    var currencyformat="USD"+currencyCode;
    var linkCurncy = responseJSON.quotes[currencyformat];
    var resultC = amount * linkCurncy;
    document.getElementById("result").innerHTML = amount + ' USD: '+ ' = '+ resultC + ' '+ currencyCode;
    document.getElementById("localC").innerHTML = 'The Local Currency is: ' + currencyName;
    
}
    
    
}
