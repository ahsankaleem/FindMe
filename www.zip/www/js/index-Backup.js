/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
        var currencyCode;
        if (cordova.platformId == 'android') {
    StatusBar.backgroundColorByHexString("#FFF");
}
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
        
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
       // app.receivedEvent('deviceready');
       navigator.geolocation.getCurrentPosition(app.onSuccess, app.onError);
        
    },

    onSuccess: function(position){
        var longitude = position.coords.longitude;
        var latitude = position.coords.latitude;
        var times = position.timestamp;
        var latLong = new google.maps.LatLng(latitude, longitude);
       
         
        
        var mapOptions = {
            center: latLong,
            zoom: 13,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };

        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
	
        var marker = new google.maps.Marker({
              position: latLong,
              map: map,
              title: 'my location'
          });
        
        
        document.getElementById("demo").innerHTML = times;
      
    
    },
    
  onError: function(error){
        alert("the code is " + error.code + ". \n" + "message: " + error.message);
    },   
    
    

};

//Geo Location Function
var currencyCode='sdsf';


// Weather update Function
function getLocationInfo() {

    navigator.geolocation.getCurrentPosition
    (onLocationSuccess, onLocationError, { enableHighAccuracy: true });
}

// Success callback for get geo coordinates

var onLocationSuccess = function (position) {

    Latitude = position.coords.latitude;
    Longitude = position.coords.longitude;

    getLocation(Latitude, Longitude);
}

// Get weather by using coordinates

function getLocation(latitude, longitude) {
  
     var http = new XMLHttpRequest();

    // Get a free key at http://openweathermap.org/. Replace the "Your_Key_Here" string with that key.
    var LocationAppKey = "01ddd6cd5fb64aef91cdcf051478fc88";

    const queryString = 
          'https://api.opencagedata.com/geocode/v1/json?q='
      + latitude + '+' + longitude + '&key=' + LocationAppKey;
 
        

http.open('GET', queryString);
http.send();
http.onreadystatechange = (e) => {
    var response = http.responseText;
    var responseJSON = JSON.parse(response);
    //var city = 'You are in ' + responseJSON.results[0].components.road; // county . postcode . state . city . country (address: formatted)
   var currencyName = responseJSON.results[0].annotations.currency.name;
     this.currencyCode = responseJSON.results[0].annotations.currency.iso_code;
     
    // var temp = responseJSON.name + ' Temp is ' + responseJSON.main.temp +' °F';
   // document.getElementById("demo2").innerHTML = currency;
   // document.getElementById("demo3").innerHTML = temp;

   
}

}
function getWeather(latitude, longitude) {
    
     var http = new XMLHttpRequest();

    // Get a free key at http://openweathermap.org/. Replace the "Your_Key_Here" string with that key.
    var OpenWeatherAppKey = "e3a7f062ee37e183cd9b87eddc6eebc1";

    const queryString =
      'http://api.openweathermap.org/data/2.5/weather?lat='
      + latitude + '&lon=' + longitude + '&appid=' + OpenWeatherAppKey + '&units=imperial';
    alert('lt: ' + latitude + ' ln: '+ longitude);

http.open('GET', queryString);
http.send();
http.onreadystatechange = (e) => {
    var response = http.responseText;
    var responseJSON = JSON.parse(response);
    //var city = 'You are in ' + responseJSON.name;
    var temp = responseJSON.name + ' Temp is ' + responseJSON.main.temp +' °F';
    document.getElementById("temp").innerHTML = temp;
   // document.getElementById("demo3").innerHTML = temp;

    
}
}
// Error callback

function onLocationError(error) {
    console.log('code: ' + error.code + '\n' +
        'message: ' + error.message + '\n');
}

//https://api.opencagedata.com/geocode/v1/json?key=01ddd6cd5fb64aef91cdcf051478fc88&q=30%2C+69&pretty=1&no_annotations=1

//For All data included GMT and Currency
//https://api.opencagedata.com/geocode/v1/json?q=31.5242056+74.3555083&key=01ddd6cd5fb64aef91cdcf051478fc88


//Mobile Menu function
function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}


//Function for Saving the data
 
function savedData(){

    
}

//var localCurrency = 'USD'+currencyCode;

//currencyCode="USDEUR";
//CurrencyExchange Function
function currencyConverter() {
alert('CurrencyCOde'+ currencyCode);
// define from currency, to currency, and amount
//var to = document.getElementById("to").value;
var amount = document.getElementById("amount").value;
var http = new XMLHttpRequest();
const url = 'http://apilayer.net/api/live?access_key=520f8452a29405a2ec63ca2037a9ce5e'
http.open('GET', url);
http.send();
http.onreadystatechange = (e) => {
    var response = http.responseText;
    var responseJSON = JSON.parse(response);
    var currencyformat="USD"+currencyCode;
    var linkCurncy = responseJSON.quotes[currencyformat];
    var resultC = amount * linkCurncy;
    document.getElementById("result").innerHTML = amount + ' Dollars: '+ ' ='+ resultC + ' AED';
    //alert('CurrencyCOde'+ requestObj);
    
}
    
    
}