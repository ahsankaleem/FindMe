 /*var config = {
apiKey: "AIzaSyAwNO_dwyUdk4yroDhemEc62UQjqFqCLi8",
    authDomain: "phonegapfinal-16c18.firebaseapp.com",
    databaseURL: "https://phonegapfinal-16c18.firebaseio.com",
    projectId: "phonegapfinal-16c18",
    storageBucket: "phonegapfinal-16c18.appspot.com",
    messagingSenderId: "1067509049031",
    appId: "1:1067509049031:web:fef5cf11274f580ca300e2"
};
// Initialize Firebase app
firebase.initializeApp(config);
// Reference to your entire Firebase database
var myFirebase = firebase.database().ref();

var recommendations = myFirebase.child("recommendations");
       //var pushData = function(){
recommendations.push({
    "title": "The danger of a single story",
    "presenter": "Chimamanda Ngozi Adichie",
    "link": "https://www.ted.com/talks/chimamanda_adichie_the_danger_of_a_single_story"
});
//}*/